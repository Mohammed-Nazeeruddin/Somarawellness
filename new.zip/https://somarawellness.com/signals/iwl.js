<!doctype html>
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=10.0, user-scalable=yes">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Page not found - Somara Wellness</title>
<meta name='robots' content='max-image-preview:large' />

<!-- This site is optimized with the Yoast SEO Premium plugin v10.0.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Somara Wellness" />
<meta property="og:site_name" content="Somara Wellness" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - Somara Wellness" />
<meta name="twitter:site" content="@Somara_Spa" />
<!-- / Yoast SEO Premium plugin. -->

<link rel='dns-prefetch' href='//stats.wp.com' />
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Somara Wellness &raquo; Feed" href="https://somarawellness.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Somara Wellness &raquo; Comments Feed" href="https://somarawellness.com/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/somarawellness.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.5"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='sina-morphing-anim-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/sina-morphing.min.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-scroll-animation-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/de-scroll-animation.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-reveal-animation-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/de-reveal-animation.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-curtain-animation-revealer-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/revealer.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-reveal-curtain-animation-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/de-reveal-curtain-animation.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-reveal-letter-decolines-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/letter/decolines.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-reveal-letter-normalize-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/letter/normalize.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-reveal-letter-lettereffect-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/letter/lettereffect.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-reveal-letter-pater-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/letter/pater.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-staggering-animate-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/de_staggering/animate.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-staggering-css-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/css/de_staggering/de-staggering.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='jkit-elements-main-css' href='https://somarawellness.com/wp-content/plugins/jeg-elementor-kit/assets/css/elements/main.css?ver=2.6.2' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://somarawellness.com/wp-includes/css/dist/block-library/style.min.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-vendors-style-css' href='https://somarawellness.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=10.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-all-blocks-style-css' href='https://somarawellness.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-all-blocks-style.css?ver=10.9.3' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='mvvwb-style-css' href='https://somarawellness.com/wp-content/plugins/booking-for-woocommerce/assets/css/style.css?ver=4.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='custom-google-fonts-css' href='//fonts.googleapis.com/css?family=Raleway&#038;ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='chaty-front-css-css' href='https://somarawellness.com/wp-content/plugins/chaty/css/chaty-front.css?ver=3.1.71679810369' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://somarawellness.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='nk-progress-style-css' href='https://somarawellness.com/wp-content/plugins/nk-progress-counter-block/css/progress-block.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-general-css' href='https://somarawellness.com/wp-content/themes/customify/assets/css/compatibility/woocommerce.min.css?ver=8.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css' href='https://somarawellness.com/wp-content/themes/customify/assets/css/compatibility/woocommerce-smallscreen.min.css?ver=8.1.1' type='text/css' media='only screen and (max-width: 768px)' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='hfe-style-css' href='https://somarawellness.com/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=1.6.16' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://somarawellness.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.23.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://somarawellness.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.16.4' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://somarawellness.com/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min.css?ver=5.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-2100-css' href='https://somarawellness.com/wp-content/uploads/elementor/css/post-2100.css?ver=1698539075' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://somarawellness.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='eihe-front-style-css' href='https://somarawellness.com/wp-content/plugins/image-hover-effects-addon-for-elementor/assets/style.min.css?ver=1.4' type='text/css' media='all' />
<link rel='stylesheet' id='de-sticky-frontend-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/de-sticky-frontend.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='de-product-display-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/de-product-display.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://somarawellness.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://somarawellness.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.16.4' type='text/css' media='all' />
<link rel='stylesheet' id='she-header-style-css' href='https://somarawellness.com/wp-content/plugins/sticky-header-effects-for-elementor/assets/css/she-header-style.css?ver=1.6.9' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-offcanvas-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/offcanvas.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-navmenu-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/navmenu.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-headerinfo-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/headerinfo.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='navmenu-rkit-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/rkit-navmenu.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-search-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/search.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-blog-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/rkit-blog-post.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-cta-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/cta.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-blockquote-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/blockquote.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-social-share-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/social_share.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-team-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/rkit_team.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-running_text-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/running_text.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-animated_heading-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/animated_heading.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-card_slider-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/card_slider.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-accordion-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/accordion.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-testimonial_carousel-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/testimonial_carousel.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-tabs-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/tabs.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-progress-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/progress-bar.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='counter-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/css/counter.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-rtmicon-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/assets/css/style.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rkit-widget-style-css' href='https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/assets/css/rkit.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='rtform-text-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/rtform_text.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='rform-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/rform.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='spinner-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/spinner-loading.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='rform-btn-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/rform-button.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='rform-select-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/rform-select.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='rform-radiobutton-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/rform-radiobutton.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='rform-checkbox-style-css' href='https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/css/rform-checkbox.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='text-editor-style-css' href='https://somarawellness.com/wp-content/plugins/metform/public/assets/css/text-editor.css?ver=3.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-wl-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/simple-line-icons.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='htflexboxgrid-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/htflexboxgrid.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/slick.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='dethemekit-widgets-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/dethemekit-widgets.css?ver=2.0.2' type='text/css' media='all' />
<style id='dethemekit-widgets-inline-css' type='text/css'>
.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.woocommerce a.button,.woocommerce a.button:hover,.woocommerce button.button,.woocommerce button.button:hover,.woocommerce a.remove:hover,.woocommerce a.button.wc-backward,.woocommerce a.button.wc-backward:hover{background-color:#E2D0BE}.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.woocommerce a.button,.woocommerce a.button:hover,.woocommerce button.button,.woocommerce button.button:hover, .woocommerce a.button.wc-backward,.woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled],.woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a.wc-forward{color:#211F40}.woocommerce a.remove{color:#E2D0BE !important}.woocommerce .woocommerce-cart-form a.button, .woocommerce .woocommerce-cart-form button.button[type="submit"], .woocommerce .cart-collaterals a.checkout-button, .woocommerce .return-to-shop a.button.wc-backward{border:1px  }.woocommerce-info,.woocommerce-message,.woocommerce-error{border-top-color:#211F40}.woocommerce-info::before,.woocommerce-message::before,.woocommerce-error::before{color:#211F40 !important}Saved Color #1{color:#54595F !important}Saved Color #3{color:#FFF !important}Saved Color #7{color:RGBA(225, 179, 130, 0.14) !important}Saved Color #2{color:#7A7A7A !important}h1, h2, h3, h4, h5, h6{color:#E2D0BE}body, a{color:#211F40}
</style>
<link rel='stylesheet' id='dethemekit-de-carousel-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/dethemekit-de-carousel.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-4329-css' href='https://somarawellness.com/wp-content/uploads/elementor/css/post-4329.css?ver=1698544815' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://somarawellness.com/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=1.6.16' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-5150-css' href='https://somarawellness.com/wp-content/uploads/elementor/css/post-5150.css?ver=1698539075' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-ekiticons-css' href='https://somarawellness.com/wp-content/plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css?ver=2.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://somarawellness.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='customify-google-font-css' href='//fonts.googleapis.com/css?family=Raleway%3A100%2C100i%2C200%2C200i%2C300%2C300i%2C400%2C400i%2C500%2C500i%2C600%2C600i%2C700%2C700i%2C800%2C800i%2C900%2C900i%7COpen+Sans%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C700%2C700i%2C800%2C800i&#038;ver=0.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='customify-style-css' href='https://somarawellness.com/wp-content/themes/customify/style.min.css?ver=0.3.7' type='text/css' media='all' />
<style id='customify-style-inline-css' type='text/css'>
.header-top .header--row-inner,.button,button,button.button,input[type="button"],input[type="reset"],input[type="submit"],.button:not(.components-button):not(.customize-partial-edit-shortcut-button), input[type="button"]:not(.components-button):not(.customize-partial-edit-shortcut-button),input[type="reset"]:not(.components-button):not(.customize-partial-edit-shortcut-button), input[type="submit"]:not(.components-button):not(.customize-partial-edit-shortcut-button),.pagination .nav-links > *:hover,.pagination .nav-links span,.nav-menu-desktop.style-full-height .primary-menu-ul > li.current-menu-item > a, .nav-menu-desktop.style-full-height .primary-menu-ul > li.current-menu-ancestor > a,.nav-menu-desktop.style-full-height .primary-menu-ul > li > a:hover,.posts-layout .readmore-button:hover{    background-color: #235787;}.posts-layout .readmore-button {color: #235787;}.pagination .nav-links > *:hover,.pagination .nav-links span,.entry-single .tags-links a:hover, .entry-single .cat-links a:hover,.posts-layout .readmore-button,.posts-layout .readmore-button:hover{    border-color: #235787;}                 .wc-svg-btn.active,        .woocommerce-tabs.wc-tabs-horizontal ul.tabs li.active,        #review_form {            border-color: #235787;        }                .wc-svg-btn.active,        .wc-single-tabs ul.tabs li.active a,        .wc-single-tabs .tab-section.active .tab-section-heading a {            color: #235787;        }.customify-builder-btn{    background-color: #c3512f;}                 .add_to_cart_button        {            background-color: #c3512f;        }body{    color: #686868;}abbr, acronym {    border-bottom-color: #686868;}a                   {                    color: #1e4b75;} .woocommerce-account .woocommerce-MyAccount-navigation ul li.is-active a,        .woocommerce-account .woocommerce-MyAccount-navigation ul li a:hover {            color: #1e4b75;        }a:hover, a:focus,.link-meta:hover, .link-meta a:hover{    color: #111111;}article.comment .comment-post-author {background: #6d6d6d;}.pagination .nav-links > *,.link-meta, .link-meta a,.color-meta,.entry-single .tags-links:before, .entry-single .cats-links:before{    color: #6d6d6d;}.widget_price_filter .ui-slider .ui-slider-handle {    border-color: #6d6d6d;}.wc-product-inner .wc-product__category a {    color: #6d6d6d;}.widget_price_filter .ui-slider .ui-slider-range,.widget_price_filter .price_slider_amount .button {            background-color: #6d6d6d;        }h1, h2, h3, h4, h5, h6 { color: #2b2b2b;}.site-content .widget-title { color: #444444;}#page-cover {background-image: url("https://somarawellness.com/wp-content/themes/customify/assets/images/default-cover.jpg");}.header--row:not(.header--transparent).header-top .header--row-inner  {background-color: rgba(0,0,0,0.8);} .header--row:not(.header--transparent).header-bottom .header--row-inner  {background-color: rgba(255,255,255,0.62);} .sub-menu .li-duplicator {display:none !important;}.header-search_icon-item .header-search-modal  {border-style: solid;} .header-search_icon-item .search-field  {border-style: solid;} .dark-mode .header-search_box-item .search-form-fields, .header-search_box-item .search-form-fields  {border-style: none;border-top-width: 43px;border-right-width: 43px;border-bottom-width: 43px;border-left-width: 43px;border-color: #000000;border-top-left-radius: 1008px;border-top-right-radius: 1008px;border-bottom-right-radius: 1008px;border-bottom-left-radius: 1008px;box-shadow: 0px 0px 0px 0px #dd3333 ;;} .dark-mode .header-search_box-item .header-search-form button.search-submit  {color: #dd3333; text-decoration-color: #dd3333;} .nav-menu-desktop.style-border-bottom .primary-menu-ul > li > a .link-before:before, .nav-menu-desktop.style-border-top .primary-menu-ul > li > a .link-before:before  { height: 2px; }.nav-menu-desktop.style-border-bottom .primary-menu-ul > li > a .link-before:before { bottom: -4px; } .nav-menu-desktop.style-border-top .primary-menu-ul > li > a .link-before:before { top: -4px; }.builder-item--primary-menu .nav-icon-angle { width: 0px; height: 0px; }.builder-item--primary-menu .nav-menu-desktop .primary-menu-ul > li > a  {color: #dd9933; text-decoration-color: #dd9933;background-color: rgba(0,0,0,0);} .header--row:not(.header--transparent) .builder-item--primary-menu .nav-menu-desktop .primary-menu-ul > li > a:hover, .header--row:not(.header--transparent) .builder-item--primary-menu .nav-menu-desktop .primary-menu-ul > li.current-menu-item > a, .header--row:not(.header--transparent) .builder-item--primary-menu .nav-menu-desktop .primary-menu-ul > li.current-menu-ancestor > a, .header--row:not(.header--transparent) .builder-item--primary-menu .nav-menu-desktop .primary-menu-ul > li.current-menu-parent > a  {color: #0a1733; text-decoration-color: #0a1733;} .builder-item--primary-menu .nav-menu-desktop .primary-menu-ul > li > a,.builder-item-sidebar .primary-menu-sidebar .primary-menu-ul > li > a {font-family: "Raleway";font-weight: 500;font-size: 15px;line-height: 15px;letter-spacing: 5px;}a.item--button {font-family: "Open Sans";font-weight: 300;}a.item--button  {background-color: rgba(105,214,27,0.91);} .header-social-icons.customify-builder-social-icons.color-custom li a {background-color: #000000;}.header-social-icons.customify-builder-social-icons.color-custom li a {color: #ffd700;}.header-social-icons.customify-builder-social-icons li a {border-style: double;}.builder-header-wc_cart-item .cart-item-link  {color: #ffc23d; text-decoration-color: #ffc23d;} .builder-header-wc_cart-item .cart-item-link .cart-icon i  {color: #ffc23d; text-decoration-color: #ffc23d;} #cb-row--footer-main .footer--row-inner {background-color: #192033}#cb-row--footer-bottom .footer--row-inner {background-color: #040131}body  {background-color: #FFFFFF;} .woocommerce .button.add_to_cart_button, .woocommerce .button.alt,.woocommerce .button.added_to_cart, .woocommerce .button.checkout, .woocommerce .button.product_type_variable,.item--wc_cart .cart-icon .cart-qty .customify-wc-total-qty{    background-color: #c3512f;}.comment-form-rating a, .star-rating,.comment-form-rating a:hover, .comment-form-rating a:focus, .star-rating:hover, .star-rating:focus{    color: #c3512f;}span.onsale{    background-color: #ffffff;}/* CSS for desktop */#page-cover .page-cover-inner {min-height: 300px;}.header--row.header-top .customify-grid, .header--row.header-top .style-full-height .primary-menu-ul > li > a {min-height: 33px;}.header--row.header-main .customify-grid, .header--row.header-main .style-full-height .primary-menu-ul > li > a {min-height: 63px;}.header--row.header-bottom .customify-grid, .header--row.header-bottom .style-full-height .primary-menu-ul > li > a {min-height: 62px;}.site-header .site-branding img { max-width: 84px; } .site-header .cb-row--mobile .site-branding img { width: 84px; }.header--row .builder-item--logo, .builder-item.builder-item--group .item--inner.builder-item--logo {margin-right: 0px;margin-left: 0px;}.header--row .builder-first--logo {text-align: center;}.header--row .builder-first--nav-icon {text-align: right;}.header-search_icon-item .search-submit {margin-left: -40px;}.header-search_box-item .search-submit{margin-left: -40px;} .header-search_box-item .woo_bootster_search .search-submit{margin-left: -40px;} .header-search_box-item .header-search-form button.search-submit{margin-left:-40px;}.header-search_box-item .search-form-fields  {padding-top: 11px;padding-right: 11px;padding-bottom: 11px;padding-left: 11px;} .header-search_box-item .header-search-form button.search-submit  {padding-top: 1px;padding-right: 1px;padding-bottom: 1px;padding-left: 1px;} .header--row .builder-item--search_box, .builder-item.builder-item--group .item--inner.builder-item--search_box {margin-top: 0px;margin-right: 0px;margin-bottom: 0px;margin-left: 0px;}.header--row .builder-first--search_box {text-align: center;}.header--row .builder-item--primary-menu, .builder-item.builder-item--group .item--inner.builder-item--primary-menu {margin-top: -28px;margin-right: 0px;margin-bottom: 0px;margin-left: 0px;}.header--row .builder-first--primary-menu {text-align: center;}.header--row .builder-first--button {text-align: right;}.header-social-icons.customify-builder-social-icons li a { font-size: 14px; }.header-social-icons.customify-builder-social-icons li {margin-left: 2px; margin-right: 2px;}.header--row .builder-first--social-icons {text-align: left;}.builder-header-wc_cart-item .cart-icon i:before {font-size: 25px;}.header--row .builder-item--wc_cart, .builder-item.builder-item--group .item--inner.builder-item--wc_cart {margin-top: -31px;}.header--row .builder-first--wc_cart {text-align: center;}/* CSS for tablet */@media screen and (max-width: 1024px) { #page-cover .page-cover-inner {min-height: 250px;}.header--row .builder-first--nav-icon {text-align: right;}.header-search_icon-item .search-submit {margin-left: -40px;}.header-search_box-item .search-submit{margin-left: -40px;} .header-search_box-item .woo_bootster_search .search-submit{margin-left: -40px;} .header-search_box-item .header-search-form button.search-submit{margin-left:-40px;} }/* CSS for mobile */@media screen and (max-width: 568px) { #page-cover .page-cover-inner {min-height: 200px;}.header--row.header-top .customify-grid, .header--row.header-top .style-full-height .primary-menu-ul > li > a {min-height: 33px;}.site-header .site-branding img { max-width: 0px; } .site-header .cb-row--mobile .site-branding img { width: 0px; }.header--row .builder-first--logo {text-align: center;}.header--row .builder-first--nav-icon {text-align: right;}.header-search_icon-item .search-submit {margin-left: -40px;}.header-search_box-item .search-submit{margin-left: -40px;} .header-search_box-item .woo_bootster_search .search-submit{margin-left: -40px;} .header-search_box-item .header-search-form button.search-submit{margin-left:-40px;}.header--row .builder-first--primary-menu {text-align: left;}.header--row .builder-first--button {text-align: left;} }
</style>
<link rel='stylesheet' id='ekit-widget-styles-css' href='https://somarawellness.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=2.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-responsive-css' href='https://somarawellness.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=2.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://somarawellness.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='ecs-styles-css' href='https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/css/de_loop/ecs-style.css?ver=2.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_element_css-css' href='https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/css/bookingpress_element_theme.css?ver=1.0.72' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_fonts_css-css' href='https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/css/fonts/fonts.css?ver=1.0.72' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_front_css-css' href='https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/css/bookingpress_front.css?ver=1.0.72' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress-custom-service-duration-front-css' href='https://somarawellness.com/wp-content/plugins/bookingpress-custom-service-duration/css/bookingpress-custom-service-duration-front.css?ver=1.6' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_pro_front_css-css' href='https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking-pro/css/bookingpress_pro_front.css?ver=3.0' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_front_custom_css-css' href='https://somarawellness.com/wp-content/uploads/bookingpress/bookingpress_front_custom_648b1beda2295.css?ver=1.0.72' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_front_font_css_Open Sans-css' href='https://fonts.googleapis.com/css2?family=Open+Sans&#038;display=swap&#038;ver=1.0.72' type='text/css' media='all' />
<link rel='stylesheet' id='bookingpress_front_mybookings_custom_css-css' href='https://somarawellness.com/wp-content/uploads/bookingpress/bookingpress_front_mybookings_custom_648b1beda2295.css?ver=1.0.72' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Raleway%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7COpen+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.5.5' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script type="text/javascript" src="https://somarawellness.com/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://stats.wp.com/w.js?ver=202428" id="woo-tracks-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/offcanvas.js?ver=6.5.5" id="rkit-offcanvas-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/navmenu.js?ver=6.5.5" id="rkit-navmenu-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/jquery-1.12.4-wp.js?ver=6.5.5" id="jquery-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/card_slider.js?ver=1.3.4" id="card-slider-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/animated_heading.js?ver=1.3.4" id="animated-heading-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/accordion.js?ver=1.3.4" id="accordion-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/bar_chart.js?ver=1.3.4" id="bar_chart-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/line_chart.js?ver=1.3.4" id="line_chart-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/pie_chart.js?ver=1.3.4" id="pie_chart-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/js/rtform_text.js?ver=1.1.1" id="rtform-text-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/js/rform_select.js?ver=1.1.1" id="rform-select-js-js"></script>
<script type="text/javascript" id="rform-script-js-extra">
/* <![CDATA[ */
var romethemeform_ajax_url = {"ajax_url":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/romethemeform/widgets/assets/js/rform.js?ver=1.1.1" id="rform-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/jquery-migrate-1.4.1-wp.js?ver=6.5.5" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.16.4" id="font-awesome-4-shim-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/sticky-header-effects-for-elementor/assets/js/she-header.js?ver=1.6.9" id="she-header-js"></script>
<script type="text/javascript" id="dtk_ajax_load-js-extra">
/* <![CDATA[ */
var ecs_ajax_params = {"ajaxurl":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php","posts":"{\"attachment\":\"iwl-js\",\"error\":\"\",\"m\":\"\",\"p\":0,\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment_id\":0,\"name\":\"iwl-js\",\"pagename\":\"\",\"page_id\":0,\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"search_columns\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"update_menu_item_cache\":false,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":10,\"nopaging\":false,\"comments_per_page\":\"20\",\"no_found_rows\":false,\"order\":\"DESC\"}"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/de_loop/ecs_ajax_pagination.js?ver=2.0.2" id="dtk_ajax_load-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/de_loop/ecs.js?ver=2.0.2" id="ecs-script-js"></script>
<link rel="https://api.w.org/" href="https://somarawellness.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://somarawellness.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.5" />
<meta name="generator" content="WooCommerce 8.1.1" />

		<!-- GA Google Analytics @ https://m0n.co/ga -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-3CFXFH9JSE"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());
			gtag('config', 'G-3CFXFH9JSE');
		</script>

	<meta name="generator" content="Site Kit by Google 1.110.0" /><meta name="title" content="Best spa in Hyderabad | Somara wellness">
<meta name="description" content="Rejuvenate yourself with wellness and beauty right in the middle of our hectic stressed out city Hyderabad from Somara spa, across various locations in Hyderabad">
<meta name="keywords" content="Best spa in Hyderabad, Luxury spa, Day spa, Massage therapy, Facial Spa, Foot massage, Stress Buster, Ayurveda treatment.">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="English">
<meta name="facebook-domain-verification" content="01gi03p6yoeoj2vunldhiu45g7mll1" />
<style id="mystickymenu" type="text/css">#mysticky-nav { width:100%; position: static; }#mysticky-nav.wrapfixed { position:fixed; left: 0px; margin-top:0px;  z-index: 99990; -webkit-transition: 0.3s; -moz-transition: 0.3s; -o-transition: 0.3s; transition: 0.3s; -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=90)"; filter: alpha(opacity=90); opacity:0.9; background-color: #f7f5e7;}#mysticky-nav.wrapfixed .myfixed{ background-color: #f7f5e7; position: relative;top: auto;left: auto;right: auto;}#mysticky-nav .myfixed { margin:0 auto; float:none; border:0px; background:none; max-width:100%; }</style>			<style type="text/css">
																															</style>
				<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.16.4; features: e_dom_optimization, e_optimized_assets_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">

<!-- Meta Pixel Code -->
<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js?v=next');
</script>
<!-- End Meta Pixel Code -->

      <script type='text/javascript'>
        var url = window.location.origin + '?ob=open-bridge';
        fbq('set', 'openbridge', '873862270355390', url);
      </script>
    <script type='text/javascript'>fbq('init', '873862270355390', {}, {
    "agent": "wordpress-6.5.5-3.0.14"
})</script><script type='text/javascript'>
    fbq('track', 'PageView', []);
  </script>
<!-- Meta Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=873862270355390&ev=PageView&noscript=1" />
</noscript>
<!-- End Meta Pixel Code -->
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="https://somarawellness.com/wp-content/uploads/2023/10/Untitled-design-1-e1697343383683-100x100.png" sizes="32x32" />
<link rel="icon" href="https://somarawellness.com/wp-content/uploads/2023/10/Untitled-design-1-e1697343383683-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://somarawellness.com/wp-content/uploads/2023/10/Untitled-design-1-e1697343383683-300x300.png" />
<meta name="msapplication-TileImage" content="https://somarawellness.com/wp-content/uploads/2023/10/Untitled-design-1-e1697343383683-300x300.png" />
		<style type="text/css" id="wp-custom-css">
			

/** Start Envato Elements CSS: Blocks (141-3-1d55f1e76be9fb1a8d9de88accbe962f) **/

.envato-kit-138-bracket .elementor-widget-container > *:before{
	content:"[";
	color:#ffab00;
	display:inline-block;
	margin-right:4px;
	line-height:1em;
	position:relative;
	top:-1px;
}

.envato-kit-138-bracket .elementor-widget-container > *:after{
	content:"]";
	color:#ffab00;
	display:inline-block;
	margin-left:4px;
	line-height:1em;
	position:relative;
	top:-1px;
}

/** End Envato Elements CSS: Blocks (141-3-1d55f1e76be9fb1a8d9de88accbe962f) **/



/** Start Envato Elements CSS: Blocks (143-3-7969bb877702491bc5ca272e536ada9d) **/

.envato-block__preview{overflow: visible;}
/* Material Button Click Effect */
.envato-kit-140-material-hit .menu-item a,
.envato-kit-140-material-button .elementor-button{
  background-position: center;
  transition: background 0.8s;
}
.envato-kit-140-material-hit .menu-item a:hover,
.envato-kit-140-material-button .elementor-button:hover{
  background: radial-gradient(circle, transparent 1%, #fff 1%) center/15000%;
}
.envato-kit-140-material-hit .menu-item a:active,
.envato-kit-140-material-button .elementor-button:active{
  background-color: #FFF;
  background-size: 100%;
  transition: background 0s;
}

/* Field Shadow */
.envato-kit-140-big-shadow-form .elementor-field-textual{
	box-shadow: 0 20px 30px rgba(0,0,0, .05);
}

/* FAQ */
.envato-kit-140-faq .elementor-accordion .elementor-accordion-item{
	border-width: 0 0 1px !important;
}

/* Scrollable Columns */
.envato-kit-140-scrollable{
	 height: 100%;
   overflow: auto;
   overflow-x: hidden;
}

/* ImageBox: No Space */
.envato-kit-140-imagebox-nospace:hover{
	transform: scale(1.1);
	transition: all 0.3s;
}
.envato-kit-140-imagebox-nospace figure{
	line-height: 0;
}

.envato-kit-140-slide .elementor-slide-content{
	background: #FFF;
	margin-left: -60px;
	padding: 1em;
}
.envato-kit-140-carousel .slick-active:not(.slick-current)  img{
	padding: 20px !important;
	transition: all .9s;
}

/** End Envato Elements CSS: Blocks (143-3-7969bb877702491bc5ca272e536ada9d) **/



/** Start Envato Elements CSS: Blocks (135-3-c665d4805631b9a8bf464e65129b2f58) **/

.envato-block__preview{overflow: visible;}

/** End Envato Elements CSS: Blocks (135-3-c665d4805631b9a8bf464e65129b2f58) **/



/** Start Envato Elements CSS: Blocks (72-3-34d2cc762876498c8f6be5405a48e6e2) **/

.envato-block__preview{overflow: visible;}

/*Kit 69 Custom Styling for buttons */
.envato-kit-69-slide-btn .elementor-button,
.envato-kit-69-cta-btn .elementor-button,
.envato-kit-69-flip-btn .elementor-button{
	border-left: 0px !important;
	border-bottom: 0px !important;
	border-right: 0px !important;
	padding: 15px 0 0 !important;
}
.envato-kit-69-slide-btn .elementor-slide-button:hover,
.envato-kit-69-cta-btn .elementor-button:hover,
.envato-kit-69-flip-btn .elementor-button:hover{
	margin-bottom: 20px;
}
.envato-kit-69-menu .elementor-nav-menu--main a:hover{
	margin-top: -7px;
	padding-top: 4px;
	border-bottom: 1px solid #FFF;
}
/* Fix menu dropdown width */
.envato-kit-69-menu .elementor-nav-menu--dropdown{
	width: 100% !important;
}

/** End Envato Elements CSS: Blocks (72-3-34d2cc762876498c8f6be5405a48e6e2) **/



/** Start Envato Elements CSS: Blocks (105-3-0fb64e69c49a8e10692d28840c54ef95) **/

.envato-kit-102-phone-overlay {
	position: absolute !important;
	display: block !important;
	top: 0%;
	left: 0%;
	right: 0%;
	margin: auto;
	z-index: 1;
}

/** End Envato Elements CSS: Blocks (105-3-0fb64e69c49a8e10692d28840c54ef95) **/



/** Start Block Kit CSS: 141-3-1d55f1e76be9fb1a8d9de88accbe962f **/

.envato-kit-138-bracket .elementor-widget-container > *:before{
	content:"[";
	color:#ffab00;
	display:inline-block;
	margin-right:4px;
	line-height:1em;
	position:relative;
	top:-1px;
}

.envato-kit-138-bracket .elementor-widget-container > *:after{
	content:"]";
	color:#ffab00;
	display:inline-block;
	margin-left:4px;
	line-height:1em;
	position:relative;
	top:-1px;
}

/** End Block Kit CSS: 141-3-1d55f1e76be9fb1a8d9de88accbe962f **/



/** Start Block Kit CSS: 72-3-34d2cc762876498c8f6be5405a48e6e2 **/

.envato-block__preview{overflow: visible;}

/*Kit 69 Custom Styling for buttons */
.envato-kit-69-slide-btn .elementor-button,
.envato-kit-69-cta-btn .elementor-button,
.envato-kit-69-flip-btn .elementor-button{
	border-left: 0px !important;
	border-bottom: 0px !important;
	border-right: 0px !important;
	padding: 15px 0 0 !important;
}
.envato-kit-69-slide-btn .elementor-slide-button:hover,
.envato-kit-69-cta-btn .elementor-button:hover,
.envato-kit-69-flip-btn .elementor-button:hover{
	margin-bottom: 20px;
}
.envato-kit-69-menu .elementor-nav-menu--main a:hover{
	margin-top: -7px;
	padding-top: 4px;
	border-bottom: 1px solid #FFF;
}
/* Fix menu dropdown width */
.envato-kit-69-menu .elementor-nav-menu--dropdown{
	width: 100% !important;
}

/** End Block Kit CSS: 72-3-34d2cc762876498c8f6be5405a48e6e2 **/



/** Start Block Kit CSS: 144-3-3a7d335f39a8579c20cdf02f8d462582 **/

.envato-block__preview{overflow: visible;}

/* Envato Kit 141 Custom Styles - Applied to the element under Advanced */

.elementor-headline-animation-type-drop-in .elementor-headline-dynamic-wrapper{
	text-align: center;
}
.envato-kit-141-top-0 h1,
.envato-kit-141-top-0 h2,
.envato-kit-141-top-0 h3,
.envato-kit-141-top-0 h4,
.envato-kit-141-top-0 h5,
.envato-kit-141-top-0 h6,
.envato-kit-141-top-0 p {
	margin-top: 0;
}

.envato-kit-141-newsletter-inline .elementor-field-textual.elementor-size-md {
	padding-left: 1.5rem;
	padding-right: 1.5rem;
}

.envato-kit-141-bottom-0 p {
	margin-bottom: 0;
}

.envato-kit-141-bottom-8 .elementor-price-list .elementor-price-list-item .elementor-price-list-header {
	margin-bottom: .5rem;
}

.envato-kit-141.elementor-widget-testimonial-carousel.elementor-pagination-type-bullets .swiper-container {
	padding-bottom: 52px;
}

.envato-kit-141-display-inline {
	display: inline-block;
}

.envato-kit-141 .elementor-slick-slider ul.slick-dots {
	bottom: -40px;
}

/** End Block Kit CSS: 144-3-3a7d335f39a8579c20cdf02f8d462582 **/



/** Start Block Kit CSS: 143-3-7969bb877702491bc5ca272e536ada9d **/

.envato-block__preview{overflow: visible;}
/* Material Button Click Effect */
.envato-kit-140-material-hit .menu-item a,
.envato-kit-140-material-button .elementor-button{
  background-position: center;
  transition: background 0.8s;
}
.envato-kit-140-material-hit .menu-item a:hover,
.envato-kit-140-material-button .elementor-button:hover{
  background: radial-gradient(circle, transparent 1%, #fff 1%) center/15000%;
}
.envato-kit-140-material-hit .menu-item a:active,
.envato-kit-140-material-button .elementor-button:active{
  background-color: #FFF;
  background-size: 100%;
  transition: background 0s;
}

/* Field Shadow */
.envato-kit-140-big-shadow-form .elementor-field-textual{
	box-shadow: 0 20px 30px rgba(0,0,0, .05);
}

/* FAQ */
.envato-kit-140-faq .elementor-accordion .elementor-accordion-item{
	border-width: 0 0 1px !important;
}

/* Scrollable Columns */
.envato-kit-140-scrollable{
	 height: 100%;
   overflow: auto;
   overflow-x: hidden;
}

/* ImageBox: No Space */
.envato-kit-140-imagebox-nospace:hover{
	transform: scale(1.1);
	transition: all 0.3s;
}
.envato-kit-140-imagebox-nospace figure{
	line-height: 0;
}

.envato-kit-140-slide .elementor-slide-content{
	background: #FFF;
	margin-left: -60px;
	padding: 1em;
}
.envato-kit-140-carousel .slick-active:not(.slick-current)  img{
	padding: 20px !important;
	transition: all .9s;
}

/** End Block Kit CSS: 143-3-7969bb877702491bc5ca272e536ada9d **/



/** Start Block Kit CSS: 142-3-a175df65179b9ef6a5ca9f1b2c0202b9 **/

.envato-block__preview{
	overflow: visible;
}

/* Border Radius */
.envato-kit-139-accordion .elementor-widget-container{
	border-radius: 10px !important;
}
.envato-kit-139-map iframe,
.envato-kit-139-slider .slick-slide,
.envato-kit-139-flipbox .elementor-flip-box div{
		border-radius: 10px !important;

}


/** End Block Kit CSS: 142-3-a175df65179b9ef6a5ca9f1b2c0202b9 **/



/** Start Template Kit CSS: Photography Studio (css/customizer.css) **/

.envato-kit-202-carousel .elementor-slick-slider .slick-next, .envato-kit-202-carousel .elementor-slick-slider .slick-prev, .envato-kit-202-carousel .elementor-swiper-button{
	top: 80% !important;
}
.envato-kit-202-carousel .elementor-slick-slider .slick-next{
	left: -50px !important;
		
}
.envato-kit-202-carousel .elementor-slick-slider .slick-prev{
	left: -100px !important;

}
.envato-kit-202-carousel .elementor-swiper-button-next{
	left: 30px !important;
	right: auto !important;
}
.envato-kit-202-carousel .elementor-swiper-button-prev{}
/* Portfolio Media Carousel */
.envato-kit-202-portfolio .swiper-slide{
	opacity: .2;
}
.envato-kit-202-portfolio .swiper-slide-active{
	width: 70% !important;
		opacity: 1;
}
.envato-kit-202-portfolio .swiper-slide-next{
	width: 35% !important;
padding-top: 50%;
	margin-left: -100px;
	opacity: 1;
}
.envato-kit-202-portfolio .swiper-slide-next div{
	max-height: 300px;

}
.envato-kit-202-portfolio .swiper-pagination-fraction{
	text-align: left;
	padding: 3em 2em;
	font-family: sans-serif;
	font-weight: bold;
}
.envato-kit-202-portfolio .elementor-carousel-image-overlay{
	text-align: left !important;
	align-items: flex-end;
	justify-content: flex-start;
	padding: 2em 1.5em;
}
.envato-kit-202-portfolio .swiper-slide-active .elementor-carousel-image-overlay{
	opacity: .8;
}

/** End Template Kit CSS: Photography Studio (css/customizer.css) **/

		</style>
		</head>

<body data-rsssl=1 class="error404 wp-custom-logo theme-customify woocommerce-no-js ehf-template-customify ehf-stylesheet-customify jkit-color-scheme hfeed content main-layout-content sidebar_vertical_border site-full-width menu_sidebar_slide_left woocommerce later-wc-version elementor-default elementor-kit-2100">
<div id="page" class="site box-shadow">
	<a class="skip-link screen-reader-text" href="#site-content">Skip to content</a>
			<div data-elementor-type="header" data-elementor-id="4329" class="elementor elementor-4329 elementor-location-header" data-elementor-post-type="elementor_library">
								<section class="elementor-section elementor-top-section elementor-element elementor-element-79a4a67f elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="79a4a67f" data-element_type="section" id="header_pop" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-14d1f706" data-id="14d1f706" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-614fb470 elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="614fb470" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-659b971" data-id="659b971" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-400c0425 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="400c0425" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-50053ffa" data-id="50053ffa" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-71d29491 de_scroll_animation_no elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="71d29491" data-element_type="widget" data-widget_type="theme-site-logo.default">
				<div class="elementor-widget-container">
											<a href="https://somarawellness.com">
			<img width="300" height="80" src="https://somarawellness.com/wp-content/uploads/2023/10/Somara-Logo-e1696798875347-300x80.png" class="attachment-medium size-medium wp-image-6477" alt="" decoding="async" srcset="https://somarawellness.com/wp-content/uploads/2023/10/Somara-Logo-e1696798875347-300x80.png 300w, https://somarawellness.com/wp-content/uploads/2023/10/Somara-Logo-e1696798875347.png 335w" sizes="(max-width: 300px) 100vw, 300px" />				</a>
											</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-2cc4c502" data-id="2cc4c502" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-16566de3 elementor-nav-menu__align-center elementor-nav-menu--stretch elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger de_scroll_animation_no elementor-widget elementor-widget-nav-menu" data-id="16566de3" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;&quot;},&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none">
				<ul id="menu-1-16566de3" class="elementor-nav-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-4262"><a href="https://somarawellness.com" class="elementor-item">HOME</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5661"><a class="elementor-item">MASSAGES<span class="nav-icon-angle">&nbsp;</span></a>
<ul class="sub-menu elementor-nav-menu--dropdown sub-lv-0">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7129"><a href="https://somarawellness.com/aromatherapy-massage-2/" class="elementor-sub-item">Aromatherapy Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7118"><a href="https://somarawellness.com/balinese-massage-2/" class="elementor-sub-item">Balinese Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7133"><a href="https://somarawellness.com/deep-tissue-massage-2/" class="elementor-sub-item">Deep Tissue Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7139"><a href="https://somarawellness.com/swedish-massage-2/" class="elementor-sub-item">Swedish Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5140"><a href="https://somarawellness.com/reflexology-spa-treatment-in-banjara-hills-hyderabad/" class="elementor-sub-item">Reflexology</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5662"><a href="#" class="elementor-item elementor-item-anchor">BEAUTY<span class="nav-icon-angle">&nbsp;</span></a>
<ul class="sub-menu elementor-nav-menu--dropdown sub-lv-0">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5912"><a href="https://somarawellness.com/facials/" class="elementor-sub-item">Facials</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5916"><a href="https://somarawellness.com/body-scrubs/" class="elementor-sub-item">Body Scrubs</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5660"><a href="#" class="elementor-item elementor-item-anchor">LOCATIONS<span class="nav-icon-angle">&nbsp;</span></a>
<ul class="sub-menu elementor-nav-menu--dropdown sub-lv-0">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4289"><a href="https://somarawellness.com/lakdi-ka-pul-outlet/" class="elementor-sub-item">Lakdikapul</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5204"><a href="https://somarawellness.com/mercure-hotel-banjara-hills/" class="elementor-sub-item">Banjara Hills</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4941"><a href="https://somarawellness.com/mla-colony/" class="elementor-sub-item">MLA Colony</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4287"><a href="https://somarawellness.com/somajiguda-outlet/" class="elementor-sub-item">Somajiguda</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6313"><a href="https://somarawellness.com/blog-page/" class="elementor-item">BLOGS</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>			<span class="elementor-screen-only">Menu</span>
		</div>
					<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-16566de3" class="elementor-nav-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-4262"><a href="https://somarawellness.com" class="elementor-item" tabindex="-1">HOME</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5661"><a class="elementor-item" tabindex="-1">MASSAGES<span class="nav-icon-angle">&nbsp;</span></a>
<ul class="sub-menu elementor-nav-menu--dropdown sub-lv-0">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7129"><a href="https://somarawellness.com/aromatherapy-massage-2/" class="elementor-sub-item" tabindex="-1">Aromatherapy Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7118"><a href="https://somarawellness.com/balinese-massage-2/" class="elementor-sub-item" tabindex="-1">Balinese Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7133"><a href="https://somarawellness.com/deep-tissue-massage-2/" class="elementor-sub-item" tabindex="-1">Deep Tissue Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7139"><a href="https://somarawellness.com/swedish-massage-2/" class="elementor-sub-item" tabindex="-1">Swedish Massage</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5140"><a href="https://somarawellness.com/reflexology-spa-treatment-in-banjara-hills-hyderabad/" class="elementor-sub-item" tabindex="-1">Reflexology</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5662"><a href="#" class="elementor-item elementor-item-anchor" tabindex="-1">BEAUTY<span class="nav-icon-angle">&nbsp;</span></a>
<ul class="sub-menu elementor-nav-menu--dropdown sub-lv-0">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5912"><a href="https://somarawellness.com/facials/" class="elementor-sub-item" tabindex="-1">Facials</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5916"><a href="https://somarawellness.com/body-scrubs/" class="elementor-sub-item" tabindex="-1">Body Scrubs</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5660"><a href="#" class="elementor-item elementor-item-anchor" tabindex="-1">LOCATIONS<span class="nav-icon-angle">&nbsp;</span></a>
<ul class="sub-menu elementor-nav-menu--dropdown sub-lv-0">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4289"><a href="https://somarawellness.com/lakdi-ka-pul-outlet/" class="elementor-sub-item" tabindex="-1">Lakdikapul</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5204"><a href="https://somarawellness.com/mercure-hotel-banjara-hills/" class="elementor-sub-item" tabindex="-1">Banjara Hills</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4941"><a href="https://somarawellness.com/mla-colony/" class="elementor-sub-item" tabindex="-1">MLA Colony</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4287"><a href="https://somarawellness.com/somajiguda-outlet/" class="elementor-sub-item" tabindex="-1">Somajiguda</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6313"><a href="https://somarawellness.com/blog-page/" class="elementor-item" tabindex="-1">BLOGS</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
						</div>
			<div id="site-content" class="site-content">
		<div class="customify-container">
			<div class="customify-grid">
				<main id="main" class="content-area customify-col-12">
					
<div class="content-inner">
			<section class="error-404 not-found">
							<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->
						<div class="page-content widget-area">
				<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>
				<div class="widget">
					
		<form role="search" class="sidebar-search-form" action="https://somarawellness.com/">
            <label>
                <span class="screen-reader-text">Search for:</span>
                <input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" title="Search for:" />
            </label>
            <button type="submit" class="search-submit" >
                <svg aria-hidden="true" focusable="false" role="presentation" xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                    <path id="svg-search" fill="currentColor" fill-rule="evenodd" d="M12.514 14.906a8.264 8.264 0 0 1-4.322 1.21C3.668 16.116 0 12.513 0 8.07 0 3.626 3.668.023 8.192.023c4.525 0 8.193 3.603 8.193 8.047 0 2.033-.769 3.89-2.035 5.307l4.999 5.552-1.775 1.597-5.06-5.62zm-4.322-.843c3.37 0 6.102-2.684 6.102-5.993 0-3.31-2.732-5.994-6.102-5.994S2.09 4.76 2.09 8.07c0 3.31 2.732 5.993 6.102 5.993z"></path>
                </svg>
            </button>
        </form>				</div>
			</div><!-- .page-content -->
		</section><!-- .error-404 -->
		</div><!-- #.content-inner -->
              			</main><!-- #main -->
					</div><!-- #.customify-grid -->
	</div><!-- #.customify-container -->
</div><!-- #content -->
<footer class="site-footer" id="site-footer">							<div  class="footer-bottom footer--row layout-full-contained"  id="cb-row--footer-bottom"  data-row-id="bottom"  data-show-on="desktop">
								<div class="footer--row-inner footer-bottom-inner dark-mode">
									<div class="customify-container">
										<div class="customify-grid  customify-grid-top"><div class="customify-col-8_md-8_sm-12_xs-12 builder-item builder-first--footer_copyright" data-push-left="off-4 _sm-0"><div class="item--inner builder-item--footer_copyright" data-section="footer_copyright" data-item-id="footer_copyright" ><div class="builder-footer-copyright-item footer-copyright"><p>Copyright &copy; 2024 Somara Wellness &#8211; Made with<font color="red"> ♥ </font> by <a href="http://unibask.com">unibask.com</a></p>
</div></div></div></div>									</div>
								</div>
							</div>
							</footer></div><!-- #page -->

<script>
    var mvvCartButtonSelector = '.mvvwb_bookable button.single_add_to_cart_button'
    if (document.querySelectorAll(mvvCartButtonSelector).length) {

        document.querySelectorAll(mvvCartButtonSelector).forEach((item) => {
            item.setAttribute('disabled', 'disabled')
        })

    }
    if (window.jQuery) {
        jQuery(document).ready(function ($) {
            $(".variations_form").on('show_variation', function (event, variation) {
                var mvvwo_event = new CustomEvent('mvvwb_show_variation',{detail:{variation:variation}});
                $(this).get(0).dispatchEvent(mvvwo_event);

            })
        });
    }

</script>
<div class="woocommerce" id="htwlquick-viewmodal"><div class="htwl-modal-dialog product"><div class="htwl-modal-content"><button type="button" class="htcloseqv"><span class="sli sli-close"></span></button><div class="htwl-modal-body"></div></div></div></div>		<div data-elementor-type="popup" data-elementor-id="5150" class="elementor elementor-5150 elementor-location-popup" data-elementor-settings="{&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}" data-elementor-post-type="elementor_library">
								<section class="elementor-section elementor-top-section elementor-element elementor-element-d8c4229 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d8c4229" data-element_type="section">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b4ae816" data-id="b4ae816" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
					<div class="elementor-background-overlay"></div>
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-5c92666 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5c92666" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-a60e989" data-id="a60e989" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b78e61a de_scroll_animation_no elementor-widget elementor-widget-heading" data-id="b78e61a" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">50% Discount</h2>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-fcd8ce0" data-id="fcd8ce0" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-f58e08d de_scroll_animation_no elementor-widget elementor-widget-text-editor" data-id="f58e08d" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>If it is your first visit to Somara, You are eligible for 50% Discount on all services. </p><p>1 Hour Aromatherapy @ <del>2999 </del>  1499</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
						</div>
		    <!-- Meta Pixel Event Code -->
    <script type='text/javascript'>
        document.addEventListener( 'wpcf7mailsent', function( event ) {
        if( "fb_pxl_code" in event.detail.apiResponse){
          eval(event.detail.apiResponse.fb_pxl_code);
        }
      }, false );
    </script>
    <!-- End Meta Pixel Event Code -->
    <div id='fb-pxl-ajax-code'></div>	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="pswp__bg"></div>
	<div class="pswp__scroll-wrap">
		<div class="pswp__container">
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>
		<div class="pswp__ui pswp__ui--hidden">
			<div class="pswp__top-bar">
				<div class="pswp__counter"></div>
				<button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>
				<button class="pswp__button pswp__button--share" aria-label="Share"></button>
				<button class="pswp__button pswp__button--fs" aria-label="Toggle fullscreen"></button>
				<button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
				<div class="pswp__share-tooltip"></div>
			</div>
			<button class="pswp__button pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>
			<button class="pswp__button pswp__button--arrow--right" aria-label="Next (arrow right)"></button>
			<div class="pswp__caption">
				<div class="pswp__caption__center"></div>
			</div>
		</div>
	</div>
</div>
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
<link rel='stylesheet' id='jeg-dynamic-style-css' href='https://somarawellness.com/wp-content/plugins/jeg-elementor-kit/lib/jeg-framework/assets/css/jeg-dynamic-styles.css?ver=1.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-css' href='https://somarawellness.com/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.min.css?ver=8.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css' href='https://somarawellness.com/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.min.css?ver=8.1.1' type='text/css' media='all' />
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/rkit-navmenu.js?ver=1.3.4" id="navmenu-rkit-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/social_share.js?ver=1.3.4" id="social-share-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/running_text.js?ver=1.3.4" id="running-text-script-js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.1/chart.min.js?ver=1.3.4" id="chartjs-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/swiper-bundle.min.js?ver=1.3.4" id="swiperjs-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/testimonial_carousel.js?ver=1.3.4" id="rkit-testimonial_carousel-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/tabs.js?ver=1.3.4" id="rkit-tabs-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/progress.js?ver=1.3.4" id="progress-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/rometheme-for-elementor/widgets/assets/js/counter.js?ver=1.3.4" id="rkit-counter-script-js"></script>
<script type="text/javascript" id="mvvwb-front-js-extra">
/* <![CDATA[ */
var mvvwb_config = {"api_nonce":"aabeff45fc","root":"https:\/\/somarawellness.com\/wp-json\/mvvwb\/v1\/","lang":"","locale":"","config":[],"initTriggers":["qv_loader_stop","quick_view_pro:load","woosq_loaded","xt-woo-quick-view-displayed"],"dateFormat":"F j, Y","timeFormat":"g:i a"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/booking-for-woocommerce/assets/js/front.js?ver=4.1.0" id="mvvwb-front-js"></script>
<script type="text/javascript" id="chaty-front-end-js-extra">
/* <![CDATA[ */
var chaty_settings = {"ajax_url":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php","analytics":"0","capture_analytics":"0","token":"94062368b1","chaty_widgets":[{"id":0,"identifier":0,"settings":{"cta_type":"simple-view","cta_body":"","cta_head":"","cta_head_bg_color":"","cta_head_text_color":"","show_close_button":0,"position":"right","custom_position":1,"bottom_spacing":"25","side_spacing":"25","icon_view":"vertical","default_state":"open","cta_text":"","cta_text_color":"#333333","cta_bg_color":"#ffffff","show_cta":"all_time","is_pending_mesg_enabled":"off","pending_mesg_count":"","pending_mesg_count_color":"#ffffff","pending_mesg_count_bgcolor":"#dd0000","widget_icon":"chat-smile","widget_icon_url":"","font_family":"Raleway","widget_size":"40","custom_widget_size":"40","is_google_analytics_enabled":0,"close_text":"Hide","widget_color":"#FF6060","widget_rgb_color":"255,96,96","has_custom_css":0,"custom_css":"","widget_token":"b78062e059","widget_index":"","attention_effect":""},"triggers":{"has_time_delay":1,"time_delay":"3","exit_intent":1,"has_display_after_page_scroll":0,"display_after_page_scroll":"0","auto_hide_widget":0,"hide_after":0,"show_on_pages_rules":[],"time_diff":0,"has_date_scheduling_rules":0,"date_scheduling_rules":{"start_date_time":"","end_date_time":""},"date_scheduling_rules_timezone":0,"day_hours_scheduling_rules_timezone":0,"has_day_hours_scheduling_rules":[],"day_hours_scheduling_rules":[],"day_time_diff":0,"show_on_direct_visit":0,"show_on_referrer_social_network":0,"show_on_referrer_search_engines":0,"show_on_referrer_google_ads":0,"show_on_referrer_urls":[],"has_show_on_specific_referrer_urls":0,"has_traffic_source":0,"has_countries":0,"countries":[],"has_target_rules":0},"channels":[{"channel":"Phone","value":"+919704911402","hover_text":"Phone","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#03E78B\"\/><path d=\"M19.3929 14.9176C17.752 14.7684 16.2602 14.3209 14.7684 13.7242C14.0226 13.4259 13.1275 13.7242 12.8292 14.4701L11.7849 16.2602C8.65222 14.6193 6.11623 11.9341 4.47529 8.95057L6.41458 7.90634C7.16046 7.60799 7.45881 6.71293 7.16046 5.96705C6.56375 4.47529 6.11623 2.83435 5.96705 1.34259C5.96705 0.596704 5.22117 0 4.47529 0H0.745882C0.298353 0 5.69062e-07 0.298352 5.69062e-07 0.745881C5.69062e-07 3.72941 0.596704 6.71293 1.93929 9.3981C3.87858 13.575 7.30964 16.8569 11.3374 18.7962C14.0226 20.1388 17.0061 20.7355 19.9896 20.7355C20.4371 20.7355 20.7355 20.4371 20.7355 19.9896V16.4094C20.7355 15.5143 20.1388 14.9176 19.3929 14.9176Z\" transform=\"translate(9.07179 9.07178)\" fill=\"white\"\/><\/svg>","is_desktop":0,"is_mobile":1,"icon_color":"#e73903","icon_rgb_color":"231,57,3","channel_type":"Phone","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","chat_welcome_message":"","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"url":"tel:+919704911402","mobile_target":"","desktop_target":"","target":"","is_agent":0,"agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"b78062e059","widget_index":"","click_event":""},{"channel":"Whatsapp","value":"919704923043","hover_text":"Whatsapp","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#49E670\"\/><path d=\"M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z\" transform=\"translate(12.9597 12.9597)\" fill=\"#FAFAFA\"\/><path d=\"M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z\" transform=\"translate(7.7758 7.77582)\" fill=\"white\" stroke=\"white\" stroke-width=\"0.2\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"#49E670","icon_rgb_color":"73,230,112","channel_type":"Whatsapp","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"1","chat_welcome_message":"<p>How can I help you? :)<\/p>","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"url":"https:\/\/web.whatsapp.com\/send?phone=919704923043","mobile_target":"","desktop_target":"_blank","target":"_blank","is_agent":0,"agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"b78062e059","widget_index":"","click_event":""}]}],"data_analytics_settings":"off"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/chaty/js/cht-front-script.js?ver=3.1.71679810369" id="chaty-front-end-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.8.1" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/somarawellness.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.8.1" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/mystickymenu/js/morphext/morphext.min.js?ver=2.6.4" id="morphext-js-js"></script>
<script type="text/javascript" id="welcomebar-frontjs-js-extra">
/* <![CDATA[ */
var welcomebar_frontjs = {"ajaxurl":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php","days":"Days","hours":"Hours","minutes":"Minutes","seconds":"Seconds","ajax_nonce":"3c0d2a539f"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/mystickymenu/js/welcomebar-front.js?ver=2.6.4" id="welcomebar-frontjs-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/mystickymenu/js/detectmobilebrowser.js?ver=2.6.4" id="detectmobilebrowser-js"></script>
<script type="text/javascript" id="mystickymenu-js-extra">
/* <![CDATA[ */
var option = {"mystickyClass":".menu-header-menu-container","activationHeight":"0","disableWidth":"0","disableLargeWidth":"0","adminBar":"false","device_desktop":"1","device_mobile":"1","mystickyTransition":"fade","mysticky_disable_down":"false"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/mystickymenu/js/mystickymenu.min.js?ver=2.6.4" id="mystickymenu-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/nk-progress-counter-block/js/progress-block.js?ver=6.5.5" id="nk-progress-script-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.8.1.1" id="jquery-blockui-js"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/somarawellness.com\/my-cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=8.1.1" id="wc-add-to-cart-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.8.1.1" id="js-cookie-js"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","qty_pm":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=8.1.1" id="woocommerce-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=2.9.2" id="elementskit-framework-js-frontend-js"></script>
<script type="text/javascript" id="elementskit-framework-js-frontend-js-after">
/* <![CDATA[ */
		var elementskit = {
			resturl: 'https://somarawellness.com/wp-json/elementskit/v1/',
		}

		
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=2.9.2" id="ekit-widget-scripts-js"></script>
<script type="text/javascript" id="customify-themejs-js-extra">
/* <![CDATA[ */
var Customify_JS = {"is_rtl":"","css_media_queries":{"all":"%s","desktop":"%s","tablet":"@media screen and (max-width: 1024px) { %s }","mobile":"@media screen and (max-width: 568px) { %s }"},"sidebar_menu_no_duplicator":"1","wc_open_cart":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/themes/customify/assets/js/theme.min.js?ver=0.3.7" id="customify-themejs-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/themes/customify/assets/js/compatibility/woocommerce.min.js?ver=0.3.7" id="plugin-woocommerce-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.16.4" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.16.4" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},
"version":"3.16.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"additional_custom_breakpoints":true,"theme_builder_v2":true,"landing-pages":true,"page-transitions":true,"notes":true,"loop":true,"form-submissions":true,"e_scroll_snap":true},"urls":{"assets":"https:\/\/somarawellness.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_description_src":"description","woocommerce_notices_elements":[]},"post":{"id":0,"title":"Page not found - Somara Wellness","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.16.4" id="elementor-frontend-js"></script>
<script type="text/javascript" id="elementor-frontend-js-after">
/* <![CDATA[ */
var jkit_ajax_url = "https://somarawellness.com/?jkit-ajax-request=jkit_elements", jkit_nonce = "c03fb32c0f";
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/jeg-elementor-kit/assets/js/elements/sticky-element.js?ver=2.6.2" id="jkit-sticky-element-js"></script>
<script type="text/javascript" id="eael-general-js-extra">
/* <![CDATA[ */
var localize = {"ajaxurl":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php","nonce":"bd48e0c319","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"eael_translate_text":{"required_text":"is a required field","invalid_text":"Invalid","billing_text":"Billing","shipping_text":"Shipping","fg_mfp_counter_text":"of"},"page_permalink":"","cart_redirectition":"no","cart_page_url":"https:\/\/somarawellness.com\/my-cart\/","el_breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=5.8.10" id="eael-general-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.0.1" id="smartmenus-js"></script>
<script type="text/javascript" id="bookingpress_vue_js-js-before">
/* <![CDATA[ */
var appoint_ajax_obj = {"ajax_url":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_vue.min.js?ver=1.0.72" id="bookingpress_vue_js-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_axios.min.js?ver=1.0.72" id="bookingpress_axios_js-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_wordpress_vue_qs_helper.js?ver=1.0.72" id="bookingpress_wordpress_vue_helper_js-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_element.js?ver=1.0.72" id="bookingpress_element_js-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_moment.min.js?ver=1.0.72" id="bookingpress_moment_js-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_v-calendar.js?ver=1.0.72" id="bookingpress_v-calendar_js-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://somarawellness.com/wp-content/plugins/bookingpress-appointment-booking/js/bookingpress_element_en.js?ver=1.0.72" id="bookingpress_elements_locale-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/lib/ResizeSensor.min.js?ver=1.7.0" id="de-resize-sensor-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/lib/sticky-sidebar/sticky-sidebar.min.js?ver=3.3.1" id="de-sticky-sidebar-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/lib/jsticky/jquery.jsticky.js?ver=1.1.0" id="jsticky-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.15.1" id="elementor-pro-webpack-runtime-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="elementor-pro-frontend-js-before">
/* <![CDATA[ */
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php","nonce":"1867a7dc11","urls":{"assets":"https:\/\/somarawellness.com\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/somarawellness.com\/wp-json\/"},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},
"woocommerce":{"menu_cart":{"cart_page_url":"https:\/\/somarawellness.com\/my-cart\/","checkout_page_url":"https:\/\/somarawellness.com\/checkout\/","fragments_nonce":"e6c00e3b64"}},
"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/somarawellness.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.15.1" id="elementor-pro-frontend-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.15.1" id="pro-elements-handlers-js"></script>
<script type="text/javascript" id="de-sticky-frontend-js-extra">
/* <![CDATA[ */
var DeStickySettings = {"elements_data":{"sections":[],"columns":[]}};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/de-sticky-frontend.js?ver=2.0.2" id="de-sticky-frontend-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/de-active-icon-box.js?ver=2.0.2" id="de-active-icon-box-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/assets/js/de-active-column.js?ver=2.0.2" id="de-active-column-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/animate-circle.min.js?ver=2.9.2" id="animate-circle-js"></script>
<script type="text/javascript" id="elementskit-elementor-js-extra">
/* <![CDATA[ */
var ekit_config = {"ajaxurl":"https:\/\/somarawellness.com\/wp-admin\/admin-ajax.php","nonce":"cc51973449"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor.js?ver=2.9.2" id="elementskit-elementor-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.15.1" id="e-sticky-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/anime.min.js?ver=6.5.5" id="dethemekit-anime-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/scrollMonitor.js?ver=6.5.5" id="de-scroll-animation-scrollmonitor-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/de_scroll_animation.preview.js?ver=6.5.5" id="de-scroll-animation-preview-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/intersectionobserver.js?ver=6.5.5" id="de-reveal-animation-intersection-observer-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/letter/charming.min.js?ver=6.5.5" id="de-reveal-letter-charming-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/letter/lineMaker.js?ver=6.5.5" id="de-reveal-letter-lineMaker-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/letter/imagesloaded.pkgd.min.js?ver=6.5.5" id="de-reveal-letter-imagesloaded-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/letter/textfx.js?ver=6.5.5" id="de-reveal-letter-textfx-js-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/main.js?ver=6.5.5" id="de-curtain-animation-main-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/de_reveal_animation.preview.js?ver=6.5.5" id="de-reveal-animation-preview-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/dethemekit-for-elementor/includes/ext/sina/assets/js/de_staggering/de_staggering.js?ver=6.5.5" id="de-staggering-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-includes/js/wp-util.min.js?ver=6.5.5" id="wp-util-js"></script>
<script type="text/javascript" id="wpforms-elementor-js-extra">
/* <![CDATA[ */
var wpformsElementorVars = {"captcha_provider":"recaptcha","recaptcha_type":"v2"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.min.js?ver=1.8.4" id="wpforms-elementor-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js?ver=1.7.21-wc.8.1.1" id="zoom-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/flexslider/jquery.flexslider.min.js?ver=2.7.2-wc.8.1.1" id="flexslider-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js?ver=4.1.1-wc.8.1.1" id="photoswipe-js"></script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js?ver=4.1.1-wc.8.1.1" id="photoswipe-ui-default-js"></script>
<script type="text/javascript" id="wc-add-to-cart-variation-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=8.1.1" id="wc-add-to-cart-variation-js"></script>
<script type="text/javascript" id="wc-single-product-js-extra">
/* <![CDATA[ */
var wc_single_product_params = {"i18n_required_rating_text":"Please select a rating","review_rating_required":"yes","flexslider":{"rtl":false,"animation":"slide","smoothHeight":true,"directionNav":false,"controlNav":"thumbnails","slideshow":false,"animationSpeed":500,"animationLoop":false,"allowOneSlide":false},"zoom_enabled":"1","zoom_options":[],"photoswipe_enabled":"1","photoswipe_options":{"shareEl":false,"closeOnScroll":false,"history":false,"hideAnimationDuration":0,"showAnimationDuration":0},"flexslider_enabled":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://somarawellness.com/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js?ver=8.1.1" id="wc-single-product-js"></script>

</body>
</html>


<!-- Page cached by LiteSpeed Cache 5.6 on 2024-07-14 15:56:06 -->